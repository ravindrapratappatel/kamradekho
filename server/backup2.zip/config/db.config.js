module.exports = {
     HOST: "127.0.0.1",
   // HOST : "localhost",      // mongod --ipv6
    PORT: 27017,
    DB: "kamradekho"
  };