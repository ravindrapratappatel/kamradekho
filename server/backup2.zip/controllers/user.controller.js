const db = require("../models");
const Room = db.room;

exports.allAccess = (req, res) => {
  // room.find().then((r)=>{
  //   console.log(r);
  //   res.status(200).send(r);
  // })
   res.status(200).send("public");
  };

  ////////// filter by location
  exports.bylocation = (req, res) => {
    const lc=req.body.location;
    Room.find({ location: { $regex: new RegExp(lc) } }).then((r)=>{
      console.log(lc);
      res.status(200).send(r);
    })
     // res.status(200).send("public");
    };

  exports.userBoard = (req, res) => {
    res.status(200).send("User Content.");
  };
  exports.adminBoard = (req, res) => {
    res.status(200).send("Admin Content.");
  };
  exports.moderatorBoard = (req, res) => {
    res.status(200).send("Moderator Content.");
  };

  ///// 
  exports.getrooms = (req, res) => {
     Room.find({}).then((data)=>{
      //console.log(data)
      res.status(200).send({
        data: data
      })
     }).catch((err)=>{
      console.log(err)
      res.send({message : "Error---"})
     })
  };
  exports.getroomsbylocation = (req, res) => {
    const roomloation = req.query.location;
    Room.find({location : { $regex: roomloation, $options: 'i'}}).then((data)=>{
     console.log(roomloation)
     res.status(200).send({data : data})
    }).catch((err)=>{
     console.log(err)
     res.send({message : "Error---"})
    })
 };