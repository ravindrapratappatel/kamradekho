const db = require("../models");
const Room = db.room;

exports.addroom = (req, res) => {
    const room = new Room({
    RoomID: req.body.roomid,
    price: req.body.price,
    location: req.body.location,
    url : req.body.url,
    description : req.body.description,
    type : req.body.type
      });

    room.save((err)=>{
       if(err) {
        res.status(500).send({ message: err });
        return;
       } 
       else{
        res.status(200).send({ message: "Room added" });
        return;
       }
    })  
  };

exports.addlocation = (req, res) => {
    res.status(200).send("location");
   };  