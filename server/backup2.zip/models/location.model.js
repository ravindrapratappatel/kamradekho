const mongoose = require("mongoose");
const Location = mongoose.model(
    "Location",
    new mongoose.Schema({
      LocationID: String,
      location: String,
    })
  );
  module.exports = Location;