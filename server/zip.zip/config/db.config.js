module.exports = {
    HOST: "localhost",
    PORT: 27017,
    DB: "my_autism_db"
  };