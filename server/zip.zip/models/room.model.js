const mongoose = require("mongoose");
const Room = mongoose.model(
  "Room",
  new mongoose.Schema({
    RoomID: String,
    price: String,
    location: String,

  })
);
module.exports = Room;