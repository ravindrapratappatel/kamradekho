const mongoose = require("mongoose");
const Product = mongoose.model(
  "Product",
  new mongoose.Schema({
    productID: String,
    price: String,
    color: String,
  })
);
module.exports = Product;