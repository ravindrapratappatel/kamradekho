const db = require("../models");
const room = db.room;

exports.allAccess = (req, res) => {
  room.find().then((r)=>{
    console.log(r);
    res.status(200).send(r);
  })
   // res.status(200).send("public");
  };

  ////////// filter by location
  exports.bylocation = (req, res) => {
    const lc=req.body.location;
    room.find({ location: { $regex: new RegExp(lc) } }).then((r)=>{
     // console.log(lc);
      res.status(200).send(r);
    })
     // res.status(200).send("public");
    };

  exports.userBoard = (req, res) => {
    res.status(200).send("User Content.");
  };
  exports.adminBoard = (req, res) => {
    res.status(200).send("Admin Content.");
  };
  exports.moderatorBoard = (req, res) => {
    res.status(200).send("Moderator Content.");
  };